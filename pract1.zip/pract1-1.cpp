#include "stdio.h"
#include "conio.h"
#include "stdlib.h"

void main()
{
	int numero=0;
	clrscr();
	gotoxy(5,1);printf("PRACTICA DE SINCRONIZACI�N DE PROGRAMAS EN C/C++. Autor: Alex Guti�rrez.");
	gotoxy(5,2);printf("PROGRAMAS EN EJECUCION: pract1.exe y pract1-1.exe");
	gotoxy(5,5);printf("Entre un numero ? ");
	gotoxy(23,5);scanf("%i",&numero);
	exit(numero);
}