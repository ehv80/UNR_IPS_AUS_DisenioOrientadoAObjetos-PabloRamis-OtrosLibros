#include "stdio.h"
#include "process.h"
#include "bios.h"
#include "conio.h"

#define ESC 27

void main()
{
	int numero1=0,numero2=0,resultado=0,salir=0,tecla;
	clrscr();
	while (!salir)
	{
		tecla=0;
		gotoxy(5,1);printf("PRACTICA DE SINCRONIZACI�N DE PROGRAMAS EN C/C++. Autor: Alex Guti�rrez.");
		gotoxy(5,2);printf("PROGRAMAS EN EJECUCION: pract1.exe                    ");
		gotoxy(5,4);printf("cargando fichero \"pract1-1.exe\".     ");
		numero1=spawnlp(P_WAIT,"pract1-1","pract1-1.exe",0);
		gotoxy(5,2);printf("PROGRAMAS EN EJECUCION: pract1.exe                    ");
		gotoxy(5,4);printf("cargando fichero \"pract1-2.exe\".     ");
		numero2=spawnlp(P_WAIT,"pract1-2","pract1-2.exe",0);
		gotoxy(5,2);printf("PROGRAMAS EN EJECUCION: pract1.exe                    ");
		gotoxy(5,5);printf("El resultado de %i + %i es %i.          ",numero1,numero2,numero1+numero2);
		gotoxy(5,6);printf("Para salir pulse ESC");
		tecla=bioskey(0);
		tecla=tecla&255;
		if (tecla==ESC) salir=1;
	}
	clrscr();
	printf("Espero que te haya sido �til... Si quieres consultar algun detalle, no dudes en escribirme por e-mail a la direcci�n \"agutierrezf@yahoo.com\". ");
}