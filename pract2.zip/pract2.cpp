#include "stdio.h"
#include "bios.h"
#include "conio.h"
#include "dos.h"

#define ESC 27

char buffer_teclado[77]="                                                                            ";
int puntero_buffer=0;
int total_teclas=0,teclas_especiales=0, teclas_normales=0;

void cursor_off(void)
{
	union REGS registros;
	registros.h.ah=0x1;
	registros.h.ch=0x20;
	registros.h.cl=0x0;
	int86(0x10,&registros,&registros);
}
void cursor_on(void)
{
	union REGS registros;
	registros.h.ah=0x1;
	registros.h.ch=0x5;
	registros.h.cl=0x6;
	int86(0x10,&registros,&registros);
}

void pon_en_buffer(char dato)
{
	if (puntero_buffer < 75)
	{
		buffer_teclado[puntero_buffer]=dato;
		puntero_buffer++;
		buffer_teclado[puntero_buffer]=' ';
		puntero_buffer++;
	}
	else
	{
		for (int i=0;i <=75;i++)
		{
			buffer_teclado[i]=buffer_teclado[i+2];
		}

		puntero_buffer-=2;
		buffer_teclado[puntero_buffer]=dato;
		puntero_buffer++;
		buffer_teclado[puntero_buffer]=' ';
		puntero_buffer++;
	}
	gotoxy(3,20);cprintf("%s",buffer_teclado);
}

void presentacion()
{
	for (int i=2;i < 80;i++)
	{
		gotoxy(i,1); cprintf("�");
		gotoxy(i,24);cprintf("�");
	}

	for (i=2; i < 24;i++)
	{
		gotoxy(1,i); cprintf("�");
		gotoxy(80,i);cprintf("�");
	}

	gotoxy(1,1);  cprintf("�");
	gotoxy(1,24); cprintf("�");
	gotoxy(80,1); cprintf("�");
	gotoxy(80,24);cprintf("�");
	textattr(YELLOW|BLUE*16);
	gotoxy(17,3); cprintf("PROGRAMA DE DEMOSTRACI�N DEL CONTROL DEL TECLADO");
	gotoxy(17,5); cprintf("Realizado por Alex Guti�rrez Ferrer�as. JULIO 2001.");
	gotoxy(3,7);  cprintf("TECLAS DE FUNCI�N");
	textattr(WHITE|BLUE*16);
	gotoxy(3,8);  cprintf("F1:   F2:   F3:    F4:    F5:    F6:    F7:    F8:    F9:    F10:   ");
	gotoxy(3,9);  cprintf("SHIFT F1:  SHIFT F2:   SHIFT F3:   SHIFT F4:   SHIFT F5:   SHIFT F6:    ");
	gotoxy(3,10); cprintf("SHIFT F7:  SHIFT F8:   SHIFT F9:   SHIFT F10:   CTRL F1:   CTRL F2:     ");
	gotoxy(3,11); cprintf("CTRL F3:  CTRL F4:   CTRL F5:   CTRL F6:   CTRL F7:   CTRL F8:  CTRL F9: ");
	gotoxy(3,12); cprintf("ALT F1:   ALT F2:   ALT F3:   ALT F4:   ALT F5:   ALT F6:   ALT F7:       ");
	gotoxy(3,13); cprintf("ALT F8:   ALT F9:   ALT F10:     ");
	textattr(YELLOW|BLUE*16);
	gotoxy(3,15); cprintf("TECLA DE DESPLAZAMIENTO DEL CURSOR");
	textattr(WHITE|BLUE*16);
	gotoxy(3,16); cprintf("IZQUIERDA:   ARRIBA:   DERECHA:   ABAJO:   PAG ARRIBA:   PAG ABAJO:  ");
	gotoxy(3,17); cprintf("INICIO:   FIN:   SUPRIMIR:   INSERTAR:   ");
	textattr(YELLOW|BLUE*16);
	gotoxy(3,19); cprintf("BUFFER DE TECLAS PULSADAS");
	textattr(BLACK|GREEN*16);
	gotoxy(3,20); cprintf("%s",buffer_teclado);
	//cprintf("����������������������������������������������������������������������������");
	textattr(YELLOW|BLUE*16);
	gotoxy(3,22); cprintf("CONTADOR DE TECLAS");
	textattr(WHITE|BLUE*16);
	gotoxy(3,23); cprintf("TOTAL TECLAS: %3i   TECLAS ESPECIALES: %3i   TECLAS NORMALES: %3i ",total_teclas,teclas_especiales,teclas_normales);
}

void proceso()
{
	// Definici�n de variables locales
	int tecla, salir=0, tecla_especial;

	while (!salir)
	{
	   if (kbhit()) // devuelve 0 si no hay una tecla pulsada
	   {
	     tecla_especial=0;
	     tecla=bioskey(0); // leer tecla
	     if ((tecla & 255)==0) // si no es un codigo ASCII normal
	     {
		tecla=tecla>>8; // obtener codigo de tecla en byte alto
		tecla_especial=1; // Es una tecla especial
	     }
	     else tecla=tecla & 255;  // es tecla normal, borrar byte alto

	     if (tecla_especial)
	     {
	      textattr(BLACK|GREEN*16);
	      switch (tecla)
	      {
		 case 59: // F1
			gotoxy(6,8); cprintf("x");
			break;
		 case 60: gotoxy(12,8); cprintf("x");
			break;
		 case 61: gotoxy(18,8); cprintf("x");
			break;
		 case 62: gotoxy(25,8); cprintf("x");
			break;
		 case 63: gotoxy(32,8); cprintf("x");
			break;
		 case 64: gotoxy(39,8); cprintf("x");
			break;
		 case 65: gotoxy(46,8); cprintf("x");
			break;
		 case 66: gotoxy(53,8); cprintf("x");
			break;
		 case 67: gotoxy(60,8); cprintf("x");
			break;
		 case 68: gotoxy(68,8); cprintf("x");
			break;
		 case 84: gotoxy(12,9); cprintf("x"); // SHIFT F1
			break;
		 case 85: gotoxy(23,9); cprintf("x");
			break;
		 case 86: gotoxy(35,9); cprintf("x");
			break;
		 case 87: gotoxy(47,9); cprintf("x");
			break;
		 case 88: gotoxy(59,9); cprintf("x");
			break;
		 case 89: gotoxy(71,9); cprintf("x");
			break;
		 case 90: gotoxy(12,10); cprintf("x");
			break;
		 case 91: gotoxy(23,10); cprintf("x");
			break;
		 case 92: gotoxy(35,10); cprintf("x");
			break;
		 case 93: gotoxy(48,10); cprintf("x");
			break;
		 case 94: gotoxy(59,10); cprintf("x");
			break;
		 case 95: gotoxy(70,10); cprintf("x");
			break;
		 case 96: gotoxy(11,11); cprintf("x");
			break;
		 case 97: gotoxy(21,11); cprintf("x");
			break;
		 case 98: gotoxy(32,11); cprintf("x");
			break;
		 case 99: gotoxy(43,11); cprintf("x");
			break;
		 case 100:gotoxy(54,11); cprintf("x");
			break;
		 case 101:gotoxy(65,11); cprintf("x");
			break;
		 case 102:gotoxy(75,11); cprintf("x");
			break;
		 case 104:gotoxy(10,12); cprintf("x");
			break;
		 case 105:gotoxy(20,12); cprintf("x");
			break;
		 case 106:gotoxy(30,12); cprintf("x");
			break;
		 case 107:gotoxy(40,12); cprintf("x");
			break;
		 case 108:gotoxy(50,12); cprintf("x");
			break;
		 case 109:gotoxy(60,12); cprintf("x");
			break;
		 case 110:gotoxy(70,12); cprintf("x");
			break;
		 case 111:gotoxy(10,13); cprintf("x");
			break;
		 case 112:gotoxy(20,13); cprintf("x");
			break;
		 case 113:gotoxy(31,13); cprintf("x");
			break;
		 case 75:// IZQ
			gotoxy(13,16); cprintf("x");
			break;
		 case 77:// DCHA
			gotoxy(34,16); cprintf("x");
			break;
		 case 72:// ARRIBA
			gotoxy(23,16); cprintf("x");
			break;
		 case 80:// ABAJO
			gotoxy(43,16); cprintf("x");
			break;
		 case 73:// PG ARRIBA
			gotoxy(57,16); cprintf("x");
			break;
		 case 81:// PG ABAJO
			gotoxy(70,16); cprintf("x");
			break;
		 case 71:// INICIO
			gotoxy(10,17); cprintf("x");
			break;
		 case 79:// FIN
			gotoxy(17,17); cprintf("x");
			break;
		 case 83:// SUPRIMIR
			gotoxy(29,17); cprintf("x");
			break;
		 case 82:// INSERTAR
			gotoxy(41,17); cprintf("x");
			break;
	      }
	      textattr(WHITE|BLUE*16);
	      teclas_especiales++;
	      total_teclas++;
	      gotoxy(17,23);cprintf("%3i",total_teclas);
	      gotoxy(42,23);cprintf("%3i",teclas_especiales);
	      gotoxy(65,23);cprintf("%3i",teclas_normales);
	      sleep(1);
	    }
	    else // es una tecla normal
	    {
		teclas_normales++;
		total_teclas++;
		presentacion();
		pon_en_buffer(tecla);
	    }
	}
	else  // es una tecla normal
	{
		presentacion();
		if (tecla==ESC) // si la tecla es ESC preguntar...
		{
			gotoxy(26,25); cprintf("Realmente desea salir (S/N) ? ");
			tecla=bioskey(0); // leer tecla
			tecla=tecla & 255; // byte alto = 0
			if ((tecla=='S')||(tecla=='s')) salir=1;
			gotoxy(26,25); cprintf("                                ");
		}
	}
     }
}

void main()
{
	cursor_off(); // Ocultar el cursor
	textattr(WHITE|BLUE*16); // Escribir en blanco sobre fondo azul
	clrscr(); // Borra la pantalla
	presentacion(); // presentaci�n inicial
	proceso();   // En esta funci�n se lee y reconocen las teclas pusadas
	cursor_on(); // Restaurar el cursor
	normvideo();
	clrscr();
	printf(" PRACTICA 2 : Demostraci�n de control del teclado, por Alex Guti�rrez.\n");
}