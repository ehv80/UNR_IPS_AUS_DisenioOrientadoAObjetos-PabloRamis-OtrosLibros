#include "stdio.h"
#include "conio.h"
#include "dos.h"
#include "bios.h"

#define REG1 0x378
#define REG2 0x379
#define REG3 0x37A

#define ESC 27

#define F1 59
#define F2 60
#define F3 61
#define F4 62
#define F5 63
#define F6 64
#define F7 65
#define F8 66
#define F9 67
#define F10 68
#define CTRL_F1 94
#define CTRL_F2 95

/* ------------------- CLASE LPT1 ------------------------------------*/
//
// (c) Desarrollada por Alex Guti�rrez Ferrer�as -- Julio de 2001
//  e-mail: agutierrezf@yahoo.com

// Esta clase C++ tiene la funci�n de controlar individualmente cada linea
// del puerto paralelo a voluntad. Tanto las lineas de salida, que son D0(2),
// D1(3), D2(4) .. D7(9), STROBE(1), SLCT_IN(17), AUTOFEED(14), e INIT(16),
// como las de entrada, que son ERROR(15), SLCT(13), PE(12), ACK(10)
// y BUSY(11). En su desarrollo y programaci�n ha primado la claridad en su
// programaci�n mas que la extensi�n del codigo, con un claro proposito
// educativo. Ademas sirve tambien como introducci�n a la programaci�n
// orientada a objetos en C++.
// Esta clase puede ser utilizada, copiada y difundida sin ningun limite
// y para cualquier proposito, con la �nica excepci�n de que debe nombrarse
// a su autor en el encabezamiento (comentarios) de la clase, alli donde
// se utilice.

class LPT1 // Esta clase se utiliza para el manejo del puerto paralelo
{
public:
	//     D0 ,  D1 ,  D2 ,  D3 ,  D4 ,  D5 ,  D6 ,  D7 ,!STROBE
	LPT1(int=0,int=0,int=0,int=0,int=0,int=0,int=0,int=0,int=1,
	     int=1,int=1,int=1,int=1,int=1,int=1,int=1,int=1);
	//   !ATFD,!INIT,!SL_IN,!ERROR,!SLCT, !PE ,!ACK ,BUSY
	// LPT1 es el constructor de la clase LPT1

	// --------------------------------------------------------------
	void activa_D0(); // activa la linea D0 del puerto paralelo
	// D0 esta conectada al pin 2 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D0(); // desactiva la linea D0 del puerto
	// D0 esta conectada al pin 2 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D1(); // activa la salida D1 del puerto paralelo
	// D1 esta conectada al pin 3 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D1(); // desactiva la salida D1 del puerto
	// D1 esta conectada al pin 3 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D2(); // activa la salida D2 del puerto paralelo
	// D2 esta conectada al pin 4 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D2(); // desactiva la salida D2 del puerto
	// D2 esta conectada al pin 4 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D3(); // activa la linea D3 del puerto paralelo
	// D3 esta conectada al pin 5 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D3(); // desactiva la linea D3 del puerto
	// D3 esta conectada al pin 5 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D4(); // activa la salida D4 del puerto paralelo
	// D4 esta conectada al pin 6 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D4(); // desactiva la salida D4 del puerto
	// D4 esta conectada al pin 6 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D5(); // activa la salida D5 del puerto paralelo
	// D5 esta conectada al pin 7 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D5(); // desactiva la salida D5 del puerto
	// D5 esta conectada al pin 7 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D6(); // activa la linea D6 del puerto paralelo
	// D6 esta conectada al pin 8 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D6(); // desactiva la linea D6 del puerto
	// D6 esta conectada al pin 8 del puerto paralelo
	// --------------------------------------------------------------
	void activa_D7(); // activa la salida D7 del puerto paralelo
	// D7 esta conectada al pin 9 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_D7(); // desactiva la salida D7 del puerto
	// D7 esta conectada al pin 9 del puerto paralelo
	// --------------------------------------------------------------
	void activa_STROBE(); // activa la linea STROBE. Tiene l�gica negativa
	// STROBE esta conectado al pin 1 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_STROBE(); // desactiva la linea STROBE.
	// STROBE esta conectado al pin 1 del puerto paralelo
	// --------------------------------------------------------------
	void activa_AUTOFEED(); // activa AUTOFEED.Tiene l�gica negativa
	// AUTOFEED esta conectado al pin 14 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_AUTOFEED(); // desactiva la linea AUTOFEED.
	// AUTOFEED esta conectado al pin 14 del puerto paralelo
	// --------------------------------------------------------------
	void activa_INIT(); // activa la salida INIT del puerto paralelo.
	// � OJO ! para activar INIT escribimos un "0" en el bit 2 del re-
	// gistro 2 de LPT1, ya que esta salida tiene l�gica negativa.
	// INIT esta conectado al pin 16 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_INIT(); // desactiva la salida INIT.
	// � OJO ! para desactivar INIT escribimos un "1" en el bit 2 del
	// registro 2 de LPT1, ya que esta salida tiene l�gica negativa.
	// INIT esta conectado al pin 16 del puerto paralelo
	// --------------------------------------------------------------
	void activa_SELECT_IN(); // activa la salida SLCT_IN del puerto
	// SELECT_IN esta conectado al pin 17 del puerto paralelo
	// --------------------------------------------------------------
	void desactiva_SELECT_IN(); // desactiva la salida SLCT_IN del puerto
	// paralelo. Tiene logica negativa
	// SELECT_IN esta conectado al pin 17 del puerto paralelo
	// --------------------------------------------------------------
	int estado_ERROR(); // comprueba el estado de la patilla ERROR del
	// puerto paralelo. ERROR = patilla 15 de LPT1
	// --------------------------------------------------------------
	int estado_SLCT(); // devuelve el estado de la patilla SLCT del
	// puerto. SLCT = patilla 13 de LPT1
	// --------------------------------------------------------------
	int estado_PE(); // devuelve el estado de la patilla PE del puerto.
	// PE = patilla 12 de LPT1
	// --------------------------------------------------------------
	int estado_ACK(); // devuelve el estado de la patilla ACK del puerto
	// ACK = patilla 10 de LPT1
	// --------------------------------------------------------------
	int estado_BUSY(); // devuelve el estado de la patilla BUSY del
	// puerto paralelo. BUSY = patilla 11 de LPT1
	// --------------------------------------------------------------
	int estado_D0();
	int estado_D1();
	int estado_D2();
	int estado_D3();
	int estado_D4();
	int estado_D5();
	int estado_D6();
	int estado_D7();
	int estado_STROBE();
	int estado_AUTOFEED();
	int estado_INIT();
	int estado_SLCT_IN();

private:
// datos no accesibles desde fuera de la clase.
// Solo son accesibles por las funciones miembro de esta clase.
	int D0; // bits de registro 1 (REG1) , D0 es el LSB
	int D1; // REG1 es un registro de salidas del PC
	int D2; // D0 corresponde al pin 2 del puerto paralelo, D1 al 3 ...
	int D3; // y D7 al 9.
	int D4;
	int D5;
	int D6;
	int D7;

	int STROBE;     // bits del registro 3 (REG3), STROBE es el LSB
	int AUTOFEED;   // REG3 es un registro de salidas del PC
	int INIT;       // STROBE corresponde al pin 1 del puerto paralelo,
	int SELECT_IN;  // AUTOFEED al 14, INIT al 16 y SELECT_IN al 17.
			// ��� OJO !!!, todas funcionan con logica negativa,
			//

	int ERROR;   // bits del registro 2 (REG2), ERROR es el LSB
	int SLCT;    // REG2 es un registro de entradas al PC
	int PE;      // ERROR corresponde al pin 15 del puerto paralelo,
	int ACK;     // SLCT al 13, PE al 12, ACK al 10 y BUSY al 11
	int BUSY;    // ERROR, ACK y BUSY funcionan con logica negativa

	void in(); // acceso a las entradas del puerto paralelo
		   // solo pueden acceder las funciones miembro de LPT1
	void out();// acceso a las salidas del puerto paralelo
};

void LPT1::LPT1(int x1,int x2,int x3,int x4,int x5, int x6, int x7, int x8, int x9,
		int x10,int x11,int x12,int x13,int x14,int x15,int x16, int x17)
{
	D0=x1; D1=x2; D2=x3; D3=x4; D4=x5; D5=x6; D6=x7; D7= x8;
	STROBE=x9; AUTOFEED=x10; SELECT_IN=x11; INIT=x12;
	ERROR=x13; SLCT=x14; PE=x15; ACK=x16; BUSY=x17;
	out();  // actualiza salidas
	in();    // actualiza mapa de las entradas
}

void LPT1::in()
{
	int i=0;
	i=inportb(REG1);
	if (i & 128) D7 =1; else D7=0;
	if (i & 64)  D6 =1; else D6=0;
	if (i & 32)  D5 =1; else D5=0;
	if (i & 16)  D4 =1; else D4=0;
	if (i & 8)   D3 =1; else D3=0;
	if (i & 4)   D2 =1; else D2=0;
	if (i & 2)   D1 =1; else D1=0;
	if (i & 1)   D0 =1; else D0=0;
	i=inportb(REG2);
	if (i & 128) BUSY =0;else BUSY =1;
	if (i & 64)  ACK  =0;else ACK  =1;
	if (i & 32)  PE   =0;else PE   =1;
	if (i & 16)  SLCT =0;else SLCT =1;
	if (i & 8)   ERROR=0;else ERROR=1;
	i=inportb(REG3);
	if (i & 8)   SELECT_IN=1; else SELECT_IN=0;
	if (i & 4)   INIT=1; else INIT=0;
	if (i & 2)   AUTOFEED=1; else AUTOFEED=0;
	if (i & 1)   STROBE=1; else STROBE=0;
}

void LPT1::out()
{
	outportb(REG1,D0+D1*2+D2*4+D3*8+D4*16+D5*32+D6*64+D7*128);
	outportb(REG3,STROBE+AUTOFEED*2+INIT*4+SELECT_IN*8);
	in();
}

void LPT1::activa_D0()
{
	D0=1;
	out();
}

void LPT1::desactiva_D0()
{
	D0=0;
	out();
}

void LPT1::activa_D1()
{
	D1=1;
	out();
}

void LPT1::desactiva_D1()
{
	D1=0;
	out();
}

void LPT1::activa_D2()
{
	D2=1;
	out();
}

void LPT1::desactiva_D2()
{
	D2=0;
	out();
}

void LPT1::activa_D3()
{
	D3=1;
	out();
}

void LPT1::desactiva_D3()
{
	D3=0;
	out();
}

void LPT1::activa_D4()
{
	D4=1;
	out();
}

void LPT1::desactiva_D4()
{
	D4=0;
	out();
}

void LPT1::activa_D5()
{
	D5=1;
	out();
}

void LPT1::desactiva_D5()
{
	D5=0;
	out();
}

void LPT1::activa_D6()
{
	D6=1;
	out();
}

void LPT1::desactiva_D6()
{
	D6=0;
	out();
}

void LPT1::activa_D7()
{
	D7=1;
	out();
}

void LPT1::desactiva_D7()
{
	D7=0;
	out();
}

void LPT1::activa_AUTOFEED()
{
	AUTOFEED=0; // AUTOFEED tiene l�gica negativa
	out();
}

void LPT1::desactiva_AUTOFEED()
{
	AUTOFEED=1; // AUTOFEED tiene l�gica negativa
	out();
}

void LPT1::activa_STROBE()
{
	STROBE=0; // STROBE tiene l�gica negativa
	out();
}

void LPT1::desactiva_STROBE()
{
	STROBE=1; // STROBE tiene l�gica negativa
	out();
}

void LPT1::activa_INIT()
{
	INIT=0;
	out();
}

void LPT1::desactiva_INIT()
{
	INIT=1;
	out();
}

void LPT1::activa_SELECT_IN()
{
	SELECT_IN=0;
	out();
}

void LPT1::desactiva_SELECT_IN()
{
	SELECT_IN=1;
	out();
}

int LPT1::estado_D0()
{
	in();
	if (D0) return(1); else return(0);
}

int LPT1::estado_D1()
{
	in();
	if (D1) return(1); else return(0);
}

int LPT1::estado_D2()
{
	in();
	if (D2) return(1); else return(0);
}

int LPT1::estado_D3()
{
	in();
	if (D3) return(1); else return(0);
}

int LPT1::estado_D4()
{
	in();
	if (D4) return(1); else return(0);
}

int LPT1::estado_D5()
{
	in();
	if (D5) return(1); else return(0);
}

int LPT1::estado_D6()
{
	in();
	if (D6) return(1); else return(0);
}

int LPT1::estado_D7()
{
	in();
	if (D7) return(1); else return(0);
}

int LPT1::estado_STROBE()
{
	in();
	if (STROBE) return(0); else return(1);
}

int LPT1::estado_SLCT_IN()
{
	in();
	if (SELECT_IN) return(0); else return(1);
}

int LPT1::estado_AUTOFEED()
{
	in();
	if (AUTOFEED) return(0); else return(1);
}

int LPT1::estado_INIT()
{
	in();
	if (INIT) return(0); else return(1);
}

int LPT1::estado_ERROR()
{
	in();
	if (ERROR) return(0); else return(1);
}

int LPT1::estado_SLCT()
{
	in();
	if (SLCT) return(0); else return(1);
}

int LPT1::estado_PE()
{
	in();
	if (PE) return(0); else return(1);
}

int LPT1::estado_ACK()
{
	in();
	if (ACK) return(0); else return(1);
}

int LPT1::estado_BUSY()
{
	in();
	if (BUSY) return(1); else return(0);
}

LPT1 lpt1; // declara la variable lpt1 como variable de clase LPT1

void cursor_off(void)
{
	union REGS registros;
	registros.h.ah=0x1;
	registros.h.ch=0x20;
	registros.h.cl=0x0;
	int86(0x10,&registros,&registros);
}
void cursor_on(void)
{
	union REGS registros;
	registros.h.ah=0x1;
	registros.h.ch=0x5;
	registros.h.cl=0x6;
	int86(0x10,&registros,&registros);
}

void muestra_entradas_salidas()
{

	textattr(BLACK|GREEN*16);
	// Muestra ENTRADAS
	gotoxy(11,9);cprintf(" %i ",lpt1.estado_ERROR());
	gotoxy(24,9);cprintf(" %i ",lpt1.estado_SLCT());
	gotoxy(35,9);cprintf(" %i ",lpt1.estado_PE());
	gotoxy(47,9);cprintf(" %i ",lpt1.estado_ACK());
	gotoxy(59,9);cprintf(" %i ",lpt1.estado_BUSY());
	// Muestra SALIDAS
	gotoxy(8,13); cprintf(" %i ",lpt1.estado_D0());
	gotoxy(17,13);cprintf(" %i ",lpt1.estado_D1());
	gotoxy(26,13);cprintf(" %i ",lpt1.estado_D2());
	gotoxy(35,13);cprintf(" %i ",lpt1.estado_D3());
	gotoxy(44,13);cprintf(" %i ",lpt1.estado_D4());
	gotoxy(53,13);cprintf(" %i ",lpt1.estado_D5());
	gotoxy(62,13);cprintf(" %i ",lpt1.estado_D6());
	gotoxy(71,13);cprintf(" %i ",lpt1.estado_D7());

	gotoxy(12,15);cprintf(" %i ",lpt1.estado_STROBE());
	gotoxy(28,15);cprintf(" %i ",lpt1.estado_SLCT_IN());
	gotoxy(45,15);cprintf(" %i ",lpt1.estado_AUTOFEED());
	gotoxy(58,15);cprintf(" %i ",lpt1.estado_INIT());
	textattr(WHITE|BLUE*16);
}

void presentacion()
{
	textattr(WHITE|BLUE*16);
	clrscr();
	for (int i=2;i < 80;i++)
	{
		gotoxy(i,1); cprintf("�");
		gotoxy(i,24);cprintf("�");
	}

	for (i=2; i < 24;i++)
	{
		gotoxy(1,i); cprintf("�");
		gotoxy(80,i);cprintf("�");
	}

	gotoxy(1,1);  cprintf("�");
	gotoxy(1,24); cprintf("�");
	gotoxy(80,1); cprintf("�");
	gotoxy(80,24);cprintf("�");
	textattr(YELLOW|BLUE*16);
	gotoxy(13,3); cprintf("PROGRAMA DE DEMOSTRACI�N DEL CONTROL DEL PUERTO PARALELO");
	gotoxy(13,5); cprintf("Realizado por Alex Guti�rrez Ferrer�as. JULIO 2001.");

	gotoxy(4,7);cprintf("ESTADO DE LAS ENTRADAS:");
	gotoxy(4,11);cprintf("ESTADO DE LAS SALIDAS:");
	textattr(WHITE|BLUE*16);
	// ENTRADAS
	gotoxy(4,8); cprintf(" (15)         (13)        (12)        (10)        (11)  -> pin ");
	gotoxy(4,9); cprintf("ERROR:        SLCT:        PE:        ACK:        BUSY:        ");
	// SALIDAS
	gotoxy(4,12);cprintf("(2)      (3)      (4)      (5)      (6)      (7)      (8)      (9) -> pin");
	gotoxy(4,13);cprintf("D0:      D1:      D2:      D3:      D4:      D5:      D6:      D7:    ");
	gotoxy(4,14);cprintf("  (1)            (17)             (14)          (16)          (20) -> pin");
	gotoxy(4,15);cprintf("STROBE:        SLCT_IN:        AUTOFEED:        INIT:         GND: ");
	textattr(BLACK|GREEN*16);cprintf(" 0 ");
	textattr(YELLOW|BLUE*16);
	gotoxy(4,18);cprintf("   < Este programa utiliza el puerto LPT1 (adress 0x378,0x379,0x37A) >");
	gotoxy(4,20);cprintf("                       < Pulse ESC para salir >                       ");
	gotoxy(3,22);cprintf("<F1>..<F8>:Cambiar estado D0..D7 <F9>: Cambiar STROBE <F10>:Cambiar AUTOFEED");
	gotoxy(3,23);cprintf("<CTRL F1>: Cambiar estado SLCT IN  <CTRL F2>: Cambiar estado INIT");
	muestra_entradas_salidas();
}

void proceso()
{
	int tecla=0;
	int salir=0;
	while (!salir)
	{
		if (!kbhit()) muestra_entradas_salidas();
		else
		{
			tecla=bioskey(0);
			if ((tecla&255)==0) tecla=tecla>>8;
			else tecla=tecla&255;

			if (tecla==ESC) salir=1;
			else
			if (tecla==F1)
			{
				if (lpt1.estado_D0()) lpt1.desactiva_D0();
				else lpt1.activa_D0();
			}
			else
			if (tecla==F2)
			{
				if (lpt1.estado_D1()) lpt1.desactiva_D1();
				else lpt1.activa_D1();
			}
			else
			if (tecla==F3)
			{
				if (lpt1.estado_D2()) lpt1.desactiva_D2();
				else lpt1.activa_D2();
			}
			else
			if (tecla==F4)
			{
				if (lpt1.estado_D3()) lpt1.desactiva_D3();
				else lpt1.activa_D3();
			}
			else
			if (tecla==F5)
			{
				if (lpt1.estado_D4()) lpt1.desactiva_D4();
				else lpt1.activa_D4();
			}
			else
			if (tecla==F6)
			{
				if (lpt1.estado_D5()) lpt1.desactiva_D5();
				else lpt1.activa_D5();
			}
			else
			if (tecla==F7)
			{
				if (lpt1.estado_D6()) lpt1.desactiva_D6();
				else lpt1.activa_D6();
			}
			else
			if (tecla==F8)
			{
				if (lpt1.estado_D7()) lpt1.desactiva_D7();
				else lpt1.activa_D7();
			}
			else
			if (tecla==F9)
			{
				if (lpt1.estado_STROBE()) lpt1.desactiva_STROBE();
				else lpt1.activa_STROBE();
			}
			else
			if (tecla==F10)
			{
				if (lpt1.estado_AUTOFEED()) lpt1.desactiva_AUTOFEED();
				else lpt1.activa_AUTOFEED();
			}
			else
			if (tecla==CTRL_F1)
			{
				if (lpt1.estado_SLCT_IN()) lpt1.desactiva_SELECT_IN();
				else lpt1.activa_SELECT_IN();
			}
			else
			if (tecla==CTRL_F2)
			{
				if (lpt1.estado_INIT()) lpt1.desactiva_INIT();
				else lpt1.activa_INIT();
			}
		}
	}
}

void main()
{
	cursor_off();
	presentacion();
	proceso();
	cursor_on();
	textattr(WHITE|BLACK*16);
	lowvideo();
	clrscr();
}